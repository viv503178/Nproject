/** Pure loan math — no side effects, easy to unit-test. */

export function monthlyEmi(
  principal: number,
  annualRatePct: number,
  years: number
): number {
  const r = annualRatePct / 12 / 100;
  const n = years * 12;
  if (r === 0) return principal / n;
  const factor = Math.pow(1 + r, n);
  return (principal * r * factor) / (factor - 1);
}

export function loanSummary(
  principal: number,
  annualRatePct: number,
  years: number
) {
  const emi = monthlyEmi(principal, annualRatePct, years);
  const total = emi * years * 12;
  const interest = total - principal;
  return { emi, total, interest, principal };
}

export function formatINR(n: number): string {
  // Indian grouping: 12,34,567
  const rounded = Math.round(n);
  return "₹" + rounded.toLocaleString("en-IN");
}

export function formatLakh(rupees: number): string {
  if (rupees >= 10000000) return `₹${(rupees / 10000000).toFixed(2)} Cr`;
  return `₹${(rupees / 100000).toFixed(1)} L`;
}
