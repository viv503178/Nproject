"use client";

import { useState } from "react";

const RATES = [
  { type: "Home purchase", roi: "8.35%" },
  { type: "Balance transfer", roi: "8.40%" },
  { type: "Top-up loan", roi: "9.10%" },
  { type: "Plot + construction", roi: "8.75%" },
];

export default function RoiCloud() {
  const [open, setOpen] = useState(false);

  return (
    <div
      className="fixed right-4 bottom-6 z-40"
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      {/* Expanded rate panel */}
      <div
        className={`absolute right-0 bottom-20 w-72 origin-bottom-right transition-all duration-300 ${
          open
            ? "opacity-100 scale-100 pointer-events-auto"
            : "opacity-0 scale-95 pointer-events-none"
        }`}
        role="dialog"
        aria-label="Current rates of interest"
      >
        <div className="rounded-2xl bg-paper border border-line shadow-xl p-5">
          <p className="font-mono text-xs uppercase tracking-[0.18em] text-gold-deep">
            Today's rates
          </p>
          <h3 className="mt-1 font-display text-lg text-brand">
            Rate of interest
          </h3>
          <ul className="mt-3 divide-y divide-line">
            {RATES.map((r) => (
              <li
                key={r.type}
                className="flex items-center justify-between py-2 text-sm"
              >
                <span className="text-ink">{r.type}</span>
                <span className="font-mono text-brand font-semibold">
                  {r.roi}
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11px] text-slate">
            p.a., indicative. Final rate depends on your profile.
          </p>
        </div>
      </div>

      {/* The cloud itself */}
      <button
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-label="View rate of interest information"
        className="cloud-float relative block focus:outline-none"
      >
        <svg width="120" height="76" viewBox="0 0 120 76" aria-hidden>
          <defs>
            <linearGradient id="cloudG" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#2E68B5" />
              <stop offset="100%" stopColor="#1A4A8A" />
            </linearGradient>
          </defs>
          <g filter="url(#s)">
            <path
              fill="url(#cloudG)"
              d="M34 64c-13 0-23-9-23-21 0-11 8-20 19-21 3-12 14-21 27-21 14 0 26 10 28 24 9 1 16 8 16 18 0 11-9 20-21 20H34z"
            />
          </g>
          <text
            x="60"
            y="46"
            textAnchor="middle"
            className="fill-white"
            style={{ font: "700 20px var(--font-mono)" }}
          >
            8.35%
          </text>
          <text
            x="60"
            y="60"
            textAnchor="middle"
            className="fill-white/80"
            style={{ font: "600 8px var(--font-body)", letterSpacing: "0.1em" }}
          >
            ROI FROM
          </text>
        </svg>
      </button>
    </div>
  );
}
