export default function Footer() {
  return (
    <footer className="bg-brand-deep text-white/70 mt-20">
      <div className="mx-auto max-w-7xl px-5 py-12 grid gap-10 md:grid-cols-[2fr_1fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-2.5 text-white">
            <span className="inline-grid place-items-center h-9 w-9 rounded-lg bg-gold text-brand-deep text-base font-bold">A</span>
            <span className="font-display text-xl">Arka Home Loans</span>
          </div>
          <p className="mt-4 text-sm max-w-xs leading-relaxed">
            Transparent home loans built around the number that matters: what you pay each month.
          </p>
        </div>
        <FooterCol title="Loans" links={["Home purchase", "Balance transfer", "Top-up", "Plot + construction"]} />
        <FooterCol title="Company" links={["About", "Careers", "Press", "Contact"]} />
        <FooterCol title="Legal" links={["Privacy", "Terms", "Fair practice code", "Grievance"]} />
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto max-w-7xl px-5 py-5 flex flex-col sm:flex-row gap-2 justify-between text-xs text-white/50">
          <p>© {new Date().getFullYear()} Arka Home Loans. A fictional brand for demonstration.</p>
          <p>Rates indicative. All loans subject to approval.</p>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: string[] }) {
  return (
    <div>
      <h4 className="font-mono text-xs uppercase tracking-[0.18em] text-gold mb-3">{title}</h4>
      <ul className="space-y-2 text-sm">
        {links.map((l) => (
          <li key={l}><a href="#" className="hover:text-white transition-colors">{l}</a></li>
        ))}
      </ul>
    </div>
  );
}
