"use client";

import { useState } from "react";
import EmiCalculator from "./EmiCalculator";
import ApplyForm from "./ApplyForm";

const TABS = [
  "Calculator",
  "Apply online",
  "Approved projects",
  "FAQ",
  "Contact us",
] as const;

const PROJECTS = [
  { name: "Lodha Vista", city: "Thane", status: "Ready to move" },
  { name: "Prestige Lakeside", city: "Bengaluru", status: "Under construction" },
  { name: "Godrej Meridien", city: "Gurugram", status: "Ready to move" },
  { name: "Sobha Dream Acres", city: "Bengaluru", status: "Under construction" },
  { name: "DLF Camellias", city: "Gurugram", status: "Ready to move" },
  { name: "Mahindra Eden", city: "Bengaluru", status: "Under construction" },
];

const FAQ = [
  { q: "How is my interest rate decided?", a: "Your rate is a reference rate plus a margin set by your credit profile, income stability, and loan-to-value ratio. The exact figure is fixed in your sanction letter." },
  { q: "Are there hidden charges?", a: "No. Processing fee, valuation, and stamp duty are itemised before you sign. There are no prepayment penalties on floating-rate loans." },
  { q: "How long does approval take?", a: "An indicative decision is immediate. A full sanction typically takes two to four business days once your documents are in." },
  { q: "Which projects are pre-approved?", a: "See the Approved projects tab. A pre-approved project means faster disbursal because the legal and technical checks are already done." },
];

export default function TabPanel() {
  const [active, setActive] = useState<(typeof TABS)[number]>("Calculator");

  return (
    <div id="tabs" className="scroll-mt-20">
      {/* Parent horizontal tabs */}
      <div
        role="tablist"
        aria-label="Services"
        className="flex flex-wrap gap-1 border-b-2 border-line"
      >
        {TABS.map((t) => (
          <button
            key={t}
            role="tab"
            aria-selected={active === t}
            onClick={() => setActive(t)}
            className={`px-5 py-3 text-sm font-medium -mb-0.5 border-b-2 transition-colors ${
              active === t
                ? "border-gold text-brand"
                : "border-transparent text-slate hover:text-brand"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="py-8" role="tabpanel">
        {active === "Calculator" && (
          <div className="max-w-xl mx-auto">
            <EmiCalculator />
          </div>
        )}

        {active === "Apply online" && (
          <div className="max-w-2xl mx-auto">
            <ApplyForm />
          </div>
        )}

        {active === "Approved projects" && (
          <div>
            <p className="text-slate mb-5 max-w-2xl">
              Loans on these projects move faster — legal and technical checks
              are already complete.
            </p>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {PROJECTS.map((p) => (
                <div
                  key={p.name}
                  className="rounded-xl bg-paper border border-line p-5 hover:border-brand transition-colors"
                >
                  <h3 className="font-display text-lg text-brand">{p.name}</h3>
                  <p className="text-sm text-slate mt-1">{p.city}</p>
                  <span className="inline-block mt-3 text-xs font-medium px-2.5 py-1 rounded-full bg-mist text-ink">
                    {p.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {active === "FAQ" && (
          <div className="max-w-2xl mx-auto space-y-3">
            {FAQ.map((f) => (
              <details
                key={f.q}
                className="group rounded-xl bg-paper border border-line px-5 py-4 open:border-brand transition-colors"
              >
                <summary className="cursor-pointer list-none flex items-center justify-between font-medium text-ink">
                  {f.q}
                  <span className="text-gold-deep transition-transform group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="mt-3 text-sm text-slate leading-relaxed">{f.a}</p>
              </details>
            ))}
          </div>
        )}

        {active === "Contact us" && (
          <div className="max-w-2xl mx-auto grid sm:grid-cols-2 gap-5">
            <div className="rounded-xl bg-paper border border-line p-6">
              <h3 className="font-display text-lg text-brand">Call us</h3>
              <p className="mt-2 text-sm text-slate">Toll-free, 8am–8pm</p>
              <p className="mt-1 font-mono text-ink">1800 200 4567</p>
            </div>
            <div className="rounded-xl bg-paper border border-line p-6">
              <h3 className="font-display text-lg text-brand">Email</h3>
              <p className="mt-2 text-sm text-slate">Replies within one day</p>
              <p className="mt-1 font-mono text-ink">care@arka.example</p>
            </div>
            <div className="rounded-xl bg-paper border border-line p-6 sm:col-span-2">
              <h3 className="font-display text-lg text-brand">Registered office</h3>
              <p className="mt-2 text-sm text-slate leading-relaxed">
                Arka Home Loans (a fictional brand) · Bandra Kurla Complex ·
                Mumbai 400051
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
