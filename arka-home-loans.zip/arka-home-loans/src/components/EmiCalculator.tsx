"use client";

import { useMemo, useState } from "react";
import { loanSummary, formatINR, formatLakh } from "@/lib/loan";

const PRESETS = [2500000, 5000000, 7500000, 10000000];

export default function EmiCalculator() {
  const [amount, setAmount] = useState(5000000);
  const [rate, setRate] = useState(8.35);
  const [years, setYears] = useState(20);

  const { emi, total, interest, principal } = useMemo(
    () => loanSummary(amount, rate, years),
    [amount, rate, years]
  );
  const principalShare = Math.round((principal / total) * 100);

  return (
    <div className="rounded-2xl bg-paper border border-line shadow-sm p-6 md:p-8">
      <div className="flex items-baseline justify-between">
        <h2 className="font-display text-xl text-brand">EMI calculator</h2>
        <span className="font-mono text-xs text-slate uppercase tracking-wider">live</span>
      </div>

      <div className="mt-4 mb-7">
        <p className="text-sm text-slate">Estimated EMI</p>
        <p className="font-mono text-4xl md:text-5xl text-brand mt-1 tabular-nums">
          {formatINR(emi)}<span className="text-base text-slate"> /mo</span>
        </p>
      </div>

      <Control label="Loan amount" value={formatLakh(amount)} min={500000} max={30000000} step={100000} current={amount} onChange={setAmount} />
      <div className="flex flex-wrap gap-2 mt-3 mb-6">
        {PRESETS.map((p) => (
          <button key={p} onClick={() => setAmount(p)}
            className={`text-xs font-mono px-3 py-1.5 rounded-full border transition-colors ${
              amount === p ? "bg-brand text-paper border-brand" : "border-line text-slate hover:border-brand"
            }`}>
            {formatLakh(p)}
          </button>
        ))}
      </div>

      <Control label="Interest rate" value={`${rate.toFixed(2)}% p.a.`} min={7} max={14} step={0.05} current={rate} onChange={setRate} />
      <div className="h-6" />
      <Control label="Tenure" value={`${years} years`} min={5} max={30} step={1} current={years} onChange={setYears} />

      <div className="mt-8">
        <div className="flex h-3 rounded-full overflow-hidden">
          <div className="bg-brand" style={{ width: `${principalShare}%` }} aria-hidden />
          <div className="bg-gold flex-1" aria-hidden />
        </div>
        <dl className="mt-4 grid grid-cols-3 gap-3 text-sm">
          <div><dt className="text-slate text-xs">Principal</dt><dd className="font-mono text-brand mt-0.5">{formatLakh(principal)}</dd></div>
          <div><dt className="text-slate text-xs">Interest</dt><dd className="font-mono text-gold-deep mt-0.5">{formatLakh(interest)}</dd></div>
          <div><dt className="text-slate text-xs">Total payable</dt><dd className="font-mono text-brand mt-0.5">{formatLakh(total)}</dd></div>
        </dl>
      </div>

      <a href="#tabs" className="mt-7 block text-center bg-gold hover:bg-gold-deep text-ink font-semibold py-3.5 rounded-xl transition-colors">
        Check my eligibility
      </a>
      <p className="mt-3 text-xs text-slate text-center">
        Indicative only. Final rate depends on credit profile and is confirmed in your offer.
      </p>
    </div>
  );
}

function Control({ label, value, min, max, step, current, onChange }: {
  label: string; value: string; min: number; max: number; step: number; current: number; onChange: (n: number) => void;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between mb-2">
        <label className="text-sm text-ink font-medium">{label}</label>
        <span className="font-mono text-sm text-gold-deep">{value}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={current}
        onChange={(e) => onChange(Number(e.target.value))} aria-label={label} className="w-full" />
    </div>
  );
}
