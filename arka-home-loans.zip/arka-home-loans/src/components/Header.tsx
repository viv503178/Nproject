"use client";

import { useState } from "react";

const LINKS = [
  { href: "#tabs", label: "Calculator" },
  { href: "#tabs", label: "Apply online" },
  { href: "#sections", label: "About" },
  { href: "#tabs", label: "FAQ" },
  { href: "#tabs", label: "Contact" },
];

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-paper border-b border-line shadow-sm">
      <div className="mx-auto max-w-7xl px-5 h-18 py-3 flex items-center justify-between">
        {/* Logo — top left */}
        <a href="#top" className="flex items-center gap-2.5">
          <span className="inline-grid place-items-center h-10 w-10 rounded-lg bg-brand text-paper text-lg font-bold">
            A
          </span>
          <span className="leading-tight">
            <span className="block font-display text-xl text-brand font-semibold">
              Arka
            </span>
            <span className="block text-[10px] uppercase tracking-[0.18em] text-slate">
              Home Loans
            </span>
          </span>
        </a>

        {/* Menu — top right */}
        <nav className="hidden md:flex items-center gap-1">
          {LINKS.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="text-sm text-ink hover:text-brand px-3 py-2 rounded-md hover:bg-mist transition-colors"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#tabs"
            className="ml-2 text-sm font-semibold bg-gold hover:bg-gold-deep text-ink px-4 py-2 rounded-md transition-colors"
          >
            Apply now
          </a>
        </nav>

        <button
          className="md:hidden h-10 w-10 grid place-items-center text-brand"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          <span className="text-2xl">{open ? "✕" : "☰"}</span>
        </button>
      </div>

      {open && (
        <nav className="md:hidden border-t border-line bg-paper px-5 py-3 flex flex-col">
          {LINKS.map((l) => (
            <a
              key={l.label}
              href={l.href}
              onClick={() => setOpen(false)}
              className="py-2.5 text-ink hover:text-brand"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#tabs"
            onClick={() => setOpen(false)}
            className="mt-2 text-center font-semibold bg-gold text-ink px-4 py-3 rounded-md"
          >
            Apply now
          </a>
        </nav>
      )}
    </header>
  );
}
