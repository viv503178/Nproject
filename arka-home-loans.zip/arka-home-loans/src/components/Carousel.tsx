"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export type Slide = {
  id: string;
  eyebrow: string;
  title: string;
  body: string;
  cta: string;
};

export default function Carousel({ slides }: { slides: Slide[] }) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const count = slides.length;
  const touchStartX = useRef<number | null>(null);

  const go = useCallback(
    (next: number) => setIndex(((next % count) + count) % count),
    [count]
  );

  useEffect(() => {
    if (paused) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = setInterval(() => setIndex((i) => (i + 1) % count), 6000);
    return () => clearInterval(t);
  }, [paused, count]);

  function onTouchStart(e: React.TouchEvent) {
    touchStartX.current = e.touches[0].clientX;
  }
  function onTouchEnd(e: React.TouchEvent) {
    if (touchStartX.current === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(dx) > 50) go(dx < 0 ? index + 1 : index - 1);
    touchStartX.current = null;
  }

  const palettes = [
    "from-brand-deep to-brand",
    "from-brand to-brand-light",
    "from-[#163b6e] to-[#21568f]",
  ];

  return (
    <section
      aria-roledescription="carousel"
      aria-label="Featured offers"
      className="relative w-full overflow-hidden"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={() => setPaused(false)}
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
    >
      <div
        className="flex transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)]"
        style={{ transform: `translateX(-${index * 100}%)` }}
      >
        {slides.map((s, i) => (
          <div
            key={s.id}
            role="group"
            aria-roledescription="slide"
            aria-label={`${i + 1} of ${count}`}
            aria-hidden={i !== index}
            className={`min-w-full bg-gradient-to-r ${palettes[i % palettes.length]} text-white`}
          >
            <div className="mx-auto max-w-7xl px-5 py-16 md:py-24">
              <p className="font-mono text-xs uppercase tracking-[0.22em] text-gold">
                {s.eyebrow}
              </p>
              <h2 className="mt-3 font-display text-3xl md:text-5xl leading-[1.08] max-w-2xl">
                {s.title}
              </h2>
              <p className="mt-4 text-white/85 max-w-xl leading-relaxed">
                {s.body}
              </p>
              <a
                href="#tabs"
                className="mt-7 inline-block bg-gold hover:bg-gold-deep text-ink font-semibold px-6 py-3 rounded-md transition-colors"
              >
                {s.cta}
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* controls */}
      <div className="absolute bottom-5 left-0 right-0">
        <div className="mx-auto max-w-7xl px-5 flex items-center justify-between">
          <div className="flex gap-2" role="tablist" aria-label="Choose slide">
            {slides.map((s, i) => (
              <button
                key={s.id}
                role="tab"
                aria-selected={i === index}
                aria-label={`Go to slide ${i + 1}`}
                onClick={() => go(i)}
                className={`h-2 rounded-full transition-all ${
                  i === index ? "w-8 bg-gold" : "w-2 bg-white/40 hover:bg-white/70"
                }`}
              />
            ))}
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => go(index - 1)}
              aria-label="Previous slide"
              className="h-10 w-10 rounded-full border border-white/30 grid place-items-center hover:bg-white/10 transition-colors"
            >
              ‹
            </button>
            <button
              onClick={() => go(index + 1)}
              aria-label="Next slide"
              className="h-10 w-10 rounded-full border border-white/30 grid place-items-center hover:bg-white/10 transition-colors"
            >
              ›
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
