"use client";

import { useState } from "react";

type Errors = Partial<Record<"name" | "phone" | "email" | "city" | "consent", string>>;

export default function ApplyForm() {
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Errors>({});

  function validate(form: HTMLFormElement): Errors {
    const e: Errors = {};
    const name = (form.elements.namedItem("name") as HTMLInputElement).value.trim();
    const phone = (form.elements.namedItem("phone") as HTMLInputElement).value.trim();
    const email = (form.elements.namedItem("email") as HTMLInputElement).value.trim();
    const city = (form.elements.namedItem("city") as HTMLInputElement).value.trim();
    const consent = (form.elements.namedItem("consent") as HTMLInputElement).checked;
    if (name.length < 2) e.name = "Tell us your full name.";
    if (!/^[6-9]\d{9}$/.test(phone)) e.phone = "Enter a valid 10-digit mobile number.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) e.email = "Enter a valid email.";
    if (city.length < 2) e.city = "Which city is the property in?";
    if (!consent) e.consent = "We need your consent to contact you.";
    return e;
  }

  function onSubmit(ev: React.FormEvent<HTMLFormElement>) {
    ev.preventDefault();
    const found = validate(ev.currentTarget);
    setErrors(found);
    if (Object.keys(found).length === 0) setSubmitted(true);
  }

  if (submitted) {
    return (
      <div className="rounded-2xl bg-brand/5 border border-brand/20 p-8 text-center">
        <p className="font-display text-2xl text-brand">Thanks — we have your details.</p>
        <p className="mt-2 text-slate">
          A loan advisor will call you within one business day to walk through your options.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="rounded-2xl bg-paper border border-line shadow-sm p-6 md:p-8">
      <input type="hidden" name="csrf_token" value="server-issued-token" />
      <h3 className="font-display text-2xl text-brand">Apply online</h3>
      <p className="mt-1 text-sm text-slate">Two minutes, no impact on your credit score.</p>

      <div className="mt-6 grid sm:grid-cols-2 gap-4">
        <Field label="Full name" name="name" error={errors.name} autoComplete="name" />
        <Field label="Mobile number" name="phone" type="tel" inputMode="numeric" maxLength={10} error={errors.phone} autoComplete="tel" />
        <Field label="Email" name="email" type="email" error={errors.email} autoComplete="email" />
        <Field label="Property city" name="city" error={errors.city} autoComplete="address-level2" />
      </div>

      <label className="mt-5 flex items-start gap-3 text-sm text-slate">
        <input type="checkbox" name="consent" className="mt-1 h-4 w-4 accent-[var(--color-brand)]" />
        <span>I agree to be contacted about my loan enquiry and accept the privacy policy.</span>
      </label>
      {errors.consent && <p className="text-xs text-red-700 mt-1">{errors.consent}</p>}

      <button type="submit" className="mt-6 w-full bg-brand hover:bg-brand-deep text-paper font-semibold py-3.5 rounded-xl transition-colors">
        Get my eligibility
      </button>
    </form>
  );
}

function Field({ label, name, error, type = "text", ...rest }: {
  label: string; name: string; error?: string; type?: string;
} & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <label htmlFor={name} className="block text-sm font-medium text-ink mb-1.5">{label}</label>
      <input id={name} name={name} type={type} aria-invalid={!!error}
        aria-describedby={error ? `${name}-err` : undefined}
        className={`w-full rounded-xl border bg-mist px-3.5 py-2.5 text-ink outline-none transition-colors focus:bg-paper ${
          error ? "border-red-400" : "border-line focus:border-brand"
        }`} {...rest} />
      {error && <p id={`${name}-err`} className="text-xs text-red-700 mt-1">{error}</p>}
    </div>
  );
}
