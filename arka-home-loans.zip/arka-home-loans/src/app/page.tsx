import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Carousel, { type Slide } from "@/components/Carousel";
import RoiCloud from "@/components/RoiCloud";
import TabPanel from "@/components/TabPanel";

const SLIDES: Slide[] = [
  {
    id: "s1",
    eyebrow: "Home loans · from 8.35% p.a.",
    title: "See your monthly EMI before you commit.",
    body: "Drag the calculator, check your eligibility, and move in faster — with no prepayment penalty on floating-rate loans.",
    cta: "Calculate my EMI",
  },
  {
    id: "s2",
    eyebrow: "Balance transfer",
    title: "Move your loan over and lower your EMI.",
    body: "We re-price your outstanding balance at a better rate and handle the paperwork with your current lender.",
    cta: "Check savings",
  },
  {
    id: "s3",
    eyebrow: "Approved projects",
    title: "Buying in a pre-approved project? Disbursal is faster.",
    body: "Legal and technical checks are already done, so your funds are released sooner once you sign.",
    cta: "See projects",
  },
];

export default function Home() {
  return (
    <>
      <Header />
      <main id="top">
        {/* Full-width carousel directly below the header */}
        <Carousel slides={SLIDES} />

        {/* Three equal columns */}
        <section id="sections" className="mx-auto max-w-7xl px-5 py-14 scroll-mt-20">
          <div className="grid md:grid-cols-3 gap-6">
            {/* About Arka */}
            <article className="rounded-2xl bg-paper border border-line p-7">
              <p className="font-mono text-xs uppercase tracking-[0.18em] text-gold-deep">01</p>
              <h2 className="mt-2 font-display text-2xl text-brand">About Arka</h2>
              <p className="mt-3 text-sm text-slate leading-relaxed">
                Arka Home Loans is a digital-first lender focused on one promise:
                you should know exactly what you'll pay each month before you apply.
                No hidden fees, no surprises in the fine print, and a real advisor on
                every application.
              </p>
              <a href="#tabs" className="mt-4 inline-block text-sm font-semibold text-brand hover:text-brand-deep">
                Learn more →
              </a>
            </article>

            {/* Important Information */}
            <article className="rounded-2xl bg-paper border border-line p-7">
              <p className="font-mono text-xs uppercase tracking-[0.18em] text-gold-deep">02</p>
              <h2 className="mt-2 font-display text-2xl text-brand">Important information</h2>
              <ul className="mt-3 space-y-2.5 text-sm text-slate">
                <li className="flex gap-2"><span className="text-gold-deep">•</span> Rates from 8.35% p.a., reset to your credit profile.</li>
                <li className="flex gap-2"><span className="text-gold-deep">•</span> Up to 90% of property value funded.</li>
                <li className="flex gap-2"><span className="text-gold-deep">•</span> Tenure up to 30 years.</li>
                <li className="flex gap-2"><span className="text-gold-deep">•</span> No prepayment penalty on floating-rate loans.</li>
                <li className="flex gap-2"><span className="text-gold-deep">•</span> All fees itemised before you sign.</li>
              </ul>
            </article>

            {/* Video tutorial */}
            <article className="rounded-2xl bg-paper border border-line p-7">
              <p className="font-mono text-xs uppercase tracking-[0.18em] text-gold-deep">03</p>
              <h2 className="mt-2 font-display text-2xl text-brand">Video tutorial</h2>
              <p className="mt-3 text-sm text-slate leading-relaxed">
                A two-minute walkthrough of how to use the calculator and apply online.
              </p>
              <div className="mt-4 relative aspect-video rounded-xl overflow-hidden bg-brand-deep grid place-items-center">
                <button
                  aria-label="Play video tutorial"
                  className="h-14 w-14 rounded-full bg-gold text-brand-deep grid place-items-center text-xl shadow-lg hover:scale-105 transition-transform"
                >
                  ▶
                </button>
                <span className="absolute bottom-3 left-3 text-xs text-white/70 font-mono">02:14</span>
              </div>
            </article>
          </div>
        </section>

        {/* Parent horizontal tabbed panel */}
        <section className="mx-auto max-w-7xl px-5 pb-16">
          <TabPanel />
        </section>
      </main>

      {/* Floating ROI cloud */}
      <RoiCloud />

      <Footer />
    </>
  );
}
